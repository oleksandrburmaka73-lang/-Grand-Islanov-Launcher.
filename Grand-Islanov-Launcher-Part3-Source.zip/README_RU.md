# Grand Islanov RP Launcher — Part 3

## What works
- Native Android APK project shell (Java + WebView).
- Dark launcher UI with Home, Servers, Account, News and Settings screens.
- Server address configured: `188.127.241.74:3571`.
- Native copy-to-clipboard button.
- Play button attempts to open a compatible installed client via `samp://188.127.241.74:3571`; if no handler exists, it shows guidance and copies the address.
- Nickname is saved locally on the device only. No password is collected.
- GitHub Actions workflow builds a debug APK and uploads `Grand-Islanov.apk` as an artifact.

## Important limits
- This project does not include GTA San Andreas or a SAMP client.
- It does not confirm server availability or show live player counts.
- Server-side registration/login, live status, auto-updates and real game integration require a compatible client and backend/API. These are not implemented by this launcher shell.
- The `samp://` URI is a best-effort generic launch attempt; the installed Android client must support it.

## Build APK from an Android tablet
1. Extract this ZIP.
2. Create a GitHub repository and upload the *contents* of this project folder to the repository root (so `settings.gradle`, `app/` and `.github/` are at root).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Choose **Build Grand Islanov APK** → **Run workflow**.
5. Wait for a green successful run. Open the run, scroll to **Artifacts**, and download `Grand-Islanov-APK`.
6. Extract the downloaded artifact ZIP to get `Grand-Islanov.apk`, then open it on the Android tablet to install. Android may ask you to allow installs from that browser/file manager.

If the workflow fails, open the run and read the first red error step; the APK is not built until the workflow is green.
