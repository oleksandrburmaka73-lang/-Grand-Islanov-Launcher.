package com.grandislanov.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        web = new WebView(this);
        web.setBackgroundColor(0xFF070B12);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new LauncherBridge(), "AndroidLauncher");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    // Keep local UI in WebView; external web links open in browser.
                    if (!"file".equals(uri.getScheme())) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                        catch (Exception e) { Toast.makeText(MainActivity.this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show(); }
                        return true;
                    }
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class LauncherBridge {
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Grand Islanov server", text));
                Toast.makeText(MainActivity.this, "Адрес сервера скопирован", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface public void launchServer(String address) {
            runOnUiThread(() -> {
                String safeAddress = "188.127.241.74:3571";
                // The supplied address is deliberately fixed to the user's server.
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("samp://" + safeAddress));
                    startActivity(Intent.createChooser(intent, "Открыть через SAMP-клиент"));
                } catch (Exception e) {
                    copyText(safeAddress);
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("SAMP-клиент не найден")
                        .setMessage("Адрес сервера скопирован: " + safeAddress +
                            "\\n\\nУстанови совместимый Android SAMP-клиент и попробуй снова. Этот лаунчер не содержит саму GTA San Andreas.")
                        .setPositiveButton("Понятно", (d, w) -> d.dismiss())
                        .show();
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("if(document.querySelector('.view.active') && document.querySelector('.view.active').id!=='home'){showView('home');true}else{false}", null);
        } else super.onBackPressed();
    }
}
